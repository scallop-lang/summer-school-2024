group_name = lambda s: f"scallop.plugin.{s}"

SETUP_ARG_PARSER = "setup_arg_parser"
SETUP_ARG_PARSER_GROUP = group_name(SETUP_ARG_PARSER)

CONFIGURE = "configure"
CONFIGURE_GROUP = group_name(CONFIGURE)

LOAD_INTO_CONTEXT = "load_into_context"
LOAD_INTO_CONTEXT_GROUP = group_name(LOAD_INTO_CONTEXT)
