from .registry import PluginRegistry
