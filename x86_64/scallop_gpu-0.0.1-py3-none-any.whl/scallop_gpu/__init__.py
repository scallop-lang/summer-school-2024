from .config import setup_arg_parser, configure, get_device
